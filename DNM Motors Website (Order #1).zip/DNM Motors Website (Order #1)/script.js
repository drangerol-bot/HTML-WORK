/**
 * DNM Motors — script.js
 * Features: Sticky navbar, mobile menu, scroll animations,
 *           counter animation, parallax hero, form validation,
 *           active nav highlighting, smooth scroll.
 */

'use strict';

/* ── DOM Ready ── */
document.addEventListener('DOMContentLoaded', () => {
    initNavbar();
    initMobileMenu();
    initScrollAnimations();
    initCounters();
    initParallax();
    initForm();
    initActiveNav();
    initHeroImageLoad();
    initSpecCardEffects();
});

/* ══════════════════════════════════════
   1. NAVBAR — sticky + scroll style
══════════════════════════════════════ */
function initNavbar() {
    const navbar = document.getElementById('navbar');
    let lastScroll = 0;

    window.addEventListener('scroll', () => {
        const currentScroll = window.scrollY;

        // Add scrolled class for glassy effect
        if (currentScroll > 40) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }

        // Hide/show navbar on scroll direction
        if (currentScroll > 300) {
            if (currentScroll > lastScroll) {
                navbar.style.transform = 'translateY(-100%)';
            } else {
                navbar.style.transform = 'translateY(0)';
            }
        } else {
            navbar.style.transform = 'translateY(0)';
        }

        lastScroll = currentScroll;
    }, { passive: true });
}

/* ══════════════════════════════════════
   2. MOBILE MENU — burger toggle
══════════════════════════════════════ */
function initMobileMenu() {
    const burger = document.getElementById('burger');
    const navLinks = document.getElementById('navLinks');

    if (!burger || !navLinks) return;

    burger.addEventListener('click', () => {
        const isOpen = navLinks.classList.toggle('open');
        burger.classList.toggle('open', isOpen);
        burger.setAttribute('aria-expanded', isOpen);
        document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    // Close menu on link click
    navLinks.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('open');
            burger.classList.remove('open');
            burger.setAttribute('aria-expanded', 'false');
            document.body.style.overflow = '';
        });
    });

    // Close menu on outside click
    document.addEventListener('click', (e) => {
        if (!burger.contains(e.target) && !navLinks.contains(e.target)) {
            navLinks.classList.remove('open');
            burger.classList.remove('open');
            document.body.style.overflow = '';
        }
    });
}

/* ══════════════════════════════════════
   3. SCROLL ANIMATIONS — Intersection Observer
══════════════════════════════════════ */
function initScrollAnimations() {
    // fade-in elements
    const fadeEls = document.querySelectorAll('.fade-in');
    const fadeObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry, i) => {
            if (entry.isIntersecting) {
                // Stagger delay for sibling elements
                const siblings = Array.from(entry.target.parentElement?.children || []);
                const idx = siblings.indexOf(entry.target);
                const delay = Math.min(idx * 120, 500);
                setTimeout(() => {
                    entry.target.classList.add('visible');
                }, delay);
                fadeObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    fadeEls.forEach(el => fadeObserver.observe(el));

    // reveal elements (hero section)
    const revealEls = document.querySelectorAll('.reveal');
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                revealObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    revealEls.forEach(el => revealObserver.observe(el));
}

/* ══════════════════════════════════════
   4. COUNTER ANIMATION — stat numbers
══════════════════════════════════════ */
function initCounters() {
    const counters = document.querySelectorAll('.stat-number');
    let countersStarted = false;

    const startCounters = () => {
        if (countersStarted) return;
        countersStarted = true;

        counters.forEach(counter => {
            const target = parseInt(counter.getAttribute('data-target'), 10);
            const duration = 1800;
            const startTime = performance.now();

            const update = (currentTime) => {
                const elapsed = currentTime - startTime;
                const progress = Math.min(elapsed / duration, 1);
                // Ease-out cubic
                const eased = 1 - Math.pow(1 - progress, 3);
                counter.textContent = Math.floor(eased * target);

                if (progress < 1) {
                    requestAnimationFrame(update);
                } else {
                    counter.textContent = target;
                }
            };

            requestAnimationFrame(update);
        });
    };

    // Trigger when hero stats are visible
    const heroStats = document.querySelector('.hero-stats');
    if (heroStats) {
        const observer = new IntersectionObserver((entries) => {
            if (entries[0].isIntersecting) {
                setTimeout(startCounters, 400);
                observer.disconnect();
            }
        }, { threshold: 0.5 });
        observer.observe(heroStats);
    }
}

/* ══════════════════════════════════════
   5. PARALLAX — hero background subtle effect
══════════════════════════════════════ */
function initParallax() {
    const heroBg = document.querySelector('.hero-img');
    if (!heroBg) return;

    // Only on desktop for performance
    if (window.matchMedia('(min-width: 768px)').matches) {
        window.addEventListener('scroll', () => {
            const scrolled = window.scrollY;
            const rate = scrolled * 0.25;
            heroBg.style.transform = `scale(1.05) translateY(${rate}px)`;
        }, { passive: true });
    }
}

/* ══════════════════════════════════════
   6. HERO IMAGE LOAD — smooth reveal
══════════════════════════════════════ */
function initHeroImageLoad() {
    const heroImg = document.querySelector('.hero-img');
    if (!heroImg) return;

    if (heroImg.complete) {
        heroImg.classList.add('loaded');
    } else {
        heroImg.addEventListener('load', () => heroImg.classList.add('loaded'));
    }
}

/* ══════════════════════════════════════
   7. ACTIVE NAV HIGHLIGHTING — based on scroll section
══════════════════════════════════════ */
function initActiveNav() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const id = entry.target.id;
                navLinks.forEach(link => {
                    link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
                });
            }
        });
    }, { rootMargin: '-40% 0px -55% 0px' });

    sections.forEach(section => observer.observe(section));
}

/* ══════════════════════════════════════
   8. CONTACT FORM VALIDATION & SUBMIT
══════════════════════════════════════ */
function initForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    const nameInput = document.getElementById('name');
    const phoneInput = document.getElementById('phone');
    const carInput = document.getElementById('car');
    const nameError = document.getElementById('nameError');
    const phoneError = document.getElementById('phoneError');
    const carError = document.getElementById('carError');
    const submitBtn = document.getElementById('formSubmitBtn');
    const successMsg = document.getElementById('formSuccess');

    // Real-time validation on blur
    nameInput.addEventListener('blur', () => validateField(nameInput, nameError));
    phoneInput.addEventListener('blur', () => validateField(phoneInput, phoneError));
    carInput.addEventListener('blur', () => validateField(carInput, carError));

    // Clear error on input
    [nameInput, phoneInput, carInput].forEach(input => {
        input.addEventListener('input', () => {
            input.classList.remove('error');
            const errorEl = document.getElementById(input.id + 'Error');
            if (errorEl) errorEl.classList.remove('show');
        });
    });

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const isNameOk = validateField(nameInput, nameError);
        const isPhoneOk = validateField(phoneInput, phoneError);
        const isCarOk = validateField(carInput, carError);

        if (!isNameOk || !isPhoneOk || !isCarOk) return;

        // Simulate sending
        submitBtn.disabled = true;
        submitBtn.textContent = 'Sending...';
        submitBtn.style.opacity = '0.7';

        setTimeout(() => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `Send Request <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>`;
            submitBtn.style.opacity = '1';
            form.reset();
            successMsg.classList.add('show');
            setTimeout(() => successMsg.classList.remove('show'), 5000);
        }, 1400);
    });
}

function validateField(input, errorEl) {
    const value = input.value.trim();
    if (!value) {
        input.classList.add('error');
        errorEl.classList.add('show');
        return false;
    }
    input.classList.remove('error');
    errorEl.classList.remove('show');
    return true;
}

/* ══════════════════════════════════════
   9. SPEC CARDS — tilt micro-interaction
══════════════════════════════════════ */
function initSpecCardEffects() {
    const cards = document.querySelectorAll('.spec-card');

    cards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            const cx = rect.width / 2;
            const cy = rect.height / 2;
            const rotateX = ((y - cy) / cy) * -5;
            const rotateY = ((x - cx) / cx) * 5;
            card.style.transform = `translateY(-6px) perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = '';
            card.style.transition = 'transform 0.5s ease';
        });

        card.addEventListener('mouseenter', () => {
            card.style.transition = 'border-color 0.35s ease, box-shadow 0.35s ease';
        });
    });
}

/* ══════════════════════════════════════
   10. SMOOTH SCROLL — all anchor links
══════════════════════════════════════ */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', (e) => {
        const target = document.querySelector(anchor.getAttribute('href'));
        if (!target) return;
        e.preventDefault();
        const navHeight = document.getElementById('navbar')?.offsetHeight || 70;
        const top = target.getBoundingClientRect().top + window.scrollY - navHeight;
        window.scrollTo({ top, behavior: 'smooth' });
    });
});
